from django.apps import AppConfig


class WikkiappConfig(AppConfig):
    name = 'wikkiapp'
